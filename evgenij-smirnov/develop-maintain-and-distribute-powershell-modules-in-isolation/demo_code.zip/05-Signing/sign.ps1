﻿<#
    Building and distributing modules in isolation

    PSConfEU 2026 | Wiesbaden, Germany

    Evgenij Smirnov @it-pro-berlin.de
    
    Sample signing script with cert selection based on expiration date and EKU
    and module name retrieval from project variables
#>
$certCandidates = (Get-ChildItem Cert:\LocalMachine\My).Where({$_.HasPrivateKey -and  $_.EnhancedKeyUsageList.ObjectId -contains '1.3.6.1.5.5.7.3.3'})
if ($certCandidates.Count -eq 0) {
    Write-Host 'No signing certificate found'
    exit 3
}
$cert = ($certCandidates | Sort-Object NotAfter -Descending)[0]
Write-Host ('Selected Cert: [{2}] {0} by {1}' -f $cert.Subject, $cert.Issuer, $cert.Thumbprint)
if ([string]::IsNullOrWhiteSpace($env:PSFY_MODULE_NAME)) {
    Write-Host 'Module name not passed from pipeline'
    exit 7
}
$outputFolder = Join-Path -Path $PSScriptRoot -ChildPath $env:PSFY_MODULE_NAME
if (-not (Test-Path -Path $outputFolder -PathType Any)) {
    Write-Host 'Output folder not found'
    exit 2
}
$moduleManifestName = Join-Path -Path $outputFolder -ChildPath ('{0}.psd1' -f $env:PSFY_MODULE_NAME)
$moduleBodyName = Join-Path -Path $outputFolder -ChildPath ('{0}.psm1' -f $env:PSFY_MODULE_NAME)
Set-AuthenticodeSignature -Certificate $signingCert -FilePath $moduleManifestName
Set-AuthenticodeSignature -Certificate $signingCert -FilePath $moduleBodyName