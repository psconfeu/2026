<#
    Building and distributing modules in isolation

    PSConfEU 2026 | Wiesbaden, Germany

    Evgenij Smirnov @it-pro-berlin.de
    
    Naive signing script just using a known thumbprint and the JSON file
#>
$moduleInfo = (Get-Content -Path (Join-Path -Path $PSScriptRoot -ChildPath 'moduleinfo.json') | ConvertFrom-Json)
$outputFolder = Join-Path -Path $PSScriptRoot -ChildPath $moduleInfo.ModuleName
if (-not (Test-Path -Path $outputFolder -PathType Any)) {
    exit 2
}
$moduleManifestName = Join-Path -Path $outputFolder -ChildPath ('{0}.psd1' -f $moduleInfo.ModuleName)
$moduleBodyName = Join-Path -Path $outputFolder -ChildPath ('{0}.psm1' -f $moduleInfo.ModuleName)
$signingCert = Get-Item Cert:\LocalMachine\My\8D58B9FA9A4E373CE20D33D65DF18B1B1D65E5AF -EA SilentlyContinue
if ($null -eq $signingCert) {
    exit 7
}
Set-AuthenticodeSignature -Certificate $signingCert -FilePath $moduleManifestName
Set-AuthenticodeSignature -Certificate $signingCert -FilePath $moduleBodyName