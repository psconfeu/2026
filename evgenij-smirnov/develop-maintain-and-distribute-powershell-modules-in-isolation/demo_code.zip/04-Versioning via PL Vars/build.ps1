﻿<#
    Building and distributing modules in isolation

    PSConfEU 2026 | Wiesbaden, Germany

    Evgenij Smirnov @it-pro-berlin.de
    
    Sample build script. Use Plaster or any ther module framework that wors for you,
    this is just to demonstrate concepts.

    This version uses project variables for name, guid, description and versioning
    Version updates depending on branch name

    Important point on versioning using branch names:
    - this build script runs on merge request creation AND on merge
    - on merge request creation is too early but we know the source branch
    - on merge is when we actually want to run this but we don't know the source branch
      so cannot decide what to increment
    - this simple script will just increase on merge request 
      so if the request is not approved, you have wasted a version number
    - the "correct" way would be to use tags rather than branch names for versioning
#>
$companyName = 'WTF IT, Inc.'
$moduleAuthor = 'Alice and Bob'
$partsFolder = Join-Path -Path $PSScriptRoot -ChildPath 'parts'
if (-not (Test-Path -Path $partsFolder -PathType Container)) {
    Write-Host 'Parts container not found!'
    exit 1
}
if ([string]::IsNullOrWhiteSpace($env:PSFY_MODULE_NAME) -or [string]::IsNullOrWhiteSpace($env:PSFY_MODULE_GUID)) {
    Write-Host 'Pipeline variables not initialized, running from local moduleinfo.json'
    $jsonPath = Join-Path -Path $PSScriptRoot -ChildPath 'moduleinfo.json'
    if (Test-Path -Path $jsonPath -PathType Leaf) {
        $moduleInfo = (Get-Content -Path $jsonPath | ConvertFrom-Json)
    } else {
        Write-Host 'moduleinfo.json not found!'
        exit 1    
    }
} else {
    Write-Host 'Running within a pipeline'
    $moduleInfo = [PSCustomObject]@{
        'ModuleName' = $env:PSFY_MODULE_NAME
        'ModuleGUID' = $env:PSFY_MODULE_GUID
        'ModuleMajorVersion' = 99
        'ModuleMinorVersion' = 99
        'ModulePatch' = 999
        'Description' = $env:PSFY_MODULE_DESC
        'RequiredModules' = @()
    }
}
$outputFolder = Join-Path -Path $PSScriptRoot -ChildPath $moduleInfo.ModuleName
if (-not (Test-Path -Path $outputFolder -PathType Any)) {
    try {
        $null = New-Item -Path $outputFolder -ItemType Directory -Force -EA Stop
    } catch {
        Write-Host 'Error creating output folder: {0}' -f $_.Exception.Message
        exit 2
    }
}
if (-not ([string]::IsNullOrWhiteSpace($env:PSFY_MODULE_NAME) -or [string]::IsNullOrWhiteSpace($env:PSFY_MODULE_GUID))) {
    $doIncrement = $true
    Write-Host ('Major version from pipeline: {0}' -f $env:PSFY_MODULE_VERSION_MAJOR)
    if ($null -eq ($env:PSFY_MODULE_VERSION_MAJOR -as [int])) {
        Write-Host 'Not convertible to integer, setting to 99'
    } else {
        $moduleInfo.ModuleMajorVersion = ($env:PSFY_MODULE_VERSION_MAJOR -as [int])
    }
    Write-Host ('Minor version from pipeline: {0}' -f $env:PSFY_MODULE_VERSION_MINOR)
    if ($null -eq ($env:PSFY_MODULE_VERSION_MINOR -as [int])) {
        Write-Host 'Not convertible to integer, setting to 99'
    } else {
        $moduleInfo.ModuleMinorVersion = ($env:PSFY_MODULE_VERSION_MINOR -as [int])
    }
    Write-Host ('Patch version from pipeline: {0}' -f $env:PSFY_MODULE_VERSION_PATCH)
    if ($null -eq ($env:PSFY_MODULE_VERSION_PATCH -as [int])) {
        Write-Host 'Not convertible to integer, setting to 999'
    } else {
        $moduleInfo.ModulePatch = ($env:PSFY_MODULE_VERSION_PATCH -as [int])
    }
    if ($doIncrement) {
        Write-Host ('Pipeline source: {0}' -f $env:CI_PIPELINE_SOURCE)
        Write-Host ('Source branch: {0}' -f $env:CI_MERGE_REQUEST_SOURCE_BRANCH_NAME)
        Write-Host ('Target branch: {0}' -f $env:CI_MERGE_REQUEST_TARGET_BRANCH_NAME)
        Write-Host ('Commit branch: {0}' -f $env:CI_COMMIT_BRANCH)
        if ([string]::IsNullOrWhiteSpace($env:PSFY_PROJECT_TOKEN)) {
            Write-Host 'Cannot increment version because PSFY_PROJECT_TOKEN is missing'
            $doIncrement = $false
        }
        if ($env:CI_PIPELINE_SOURCE -ne 'merge_request_event') {
            Write-Host 'Will not increment version because this run is not on a merge request'
            $doIncrement = $false
        }
    } else {
        Write-Host 'Not all pipeline variables had correct values'
    }
    if ($doIncrement) {
        if ($env:CI_MERGE_REQUEST_SOURCE_BRANCH_NAME -match '^major\/') {
            Write-Host ('Increasing the major version from {0}, resetting minor and patch' -f $moduleInfo.ModuleMajorVersion)
            $moduleInfo.ModuleMajorVersion++
            $moduleInfo.ModuleMinorVersion = 0
            $moduleInfo.ModulePatch = 0
        } elseif ($env:CI_MERGE_REQUEST_SOURCE_BRANCH_NAME -match '^minor\/') {
            Write-Host ('Increasing the minor version from {0}, resetting patch' -f $moduleInfo.ModuleMinorVersion)
            $moduleInfo.ModuleMinorVersion++
            $moduleInfo.ModulePatch = 0
        } else {
            Write-Host ('Increasing the patch from {0}' -f $moduleInfo.ModulePatch)
            $moduleInfo.ModulePatch++
        }
        $header = @{
            'PRIVATE-TOKEN' = $env:PSFY_PROJECT_TOKEN
        }
        $apiURL = ('{0}/projects/{1}/variables/{2}' -f $env:CI_API_V4_URL, $env:CI_PROJECT_ID,'PSFY_MODULE_VERSION_PATCH')
        $form = @{
            'value' = $moduleInfo.ModulePatch
        }
        try {
            $res = Invoke-RestMethod -Uri $apiURL -Method Put -Headers $header -Form $form -Verbose:$false -EA Stop
            Write-Host ('Updated PSFY_MODULE_VERSION_PATCH to {0}' -f $moduleInfo.ModulePatch)
        } catch {
            Write-Host 'Error updating PSFY_MODULE_VERSION_PATCH: {0}' -f $_.Exception.Message
        }
        $apiURL = ('{0}/projects/{1}/variables/{2}' -f $env:CI_API_V4_URL, $env:CI_PROJECT_ID,'PSFY_MODULE_VERSION_MINOR')
        $form = @{
            'value' = $moduleInfo.ModuleMinorVersion
        }
        try {
            $res = Invoke-RestMethod -Uri $apiURL -Method Put -Headers $header -Form $form -Verbose:$false -EA Stop
            Write-Host ('Updated PSFY_MODULE_VERSION_MINOR to {0}' -f $moduleInfo.ModuleMinorVersion)
        } catch {
            Write-Host 'Error updating PSFY_MODULE_VERSION_MINOR: {0}' -f $_.Exception.Message
        }
        $apiURL = ('{0}/projects/{1}/variables/{2}' -f $env:CI_API_V4_URL, $env:CI_PROJECT_ID,'PSFY_MODULE_VERSION_MAJOR')
        $form = @{
            'value' = $moduleInfo.ModuleMajorVersion
        }
        try {
            $res = Invoke-RestMethod -Uri $apiURL -Method Put -Headers $header -Form $form -Verbose:$false -EA Stop
            Write-Host ('Updated PSFY_MODULE_VERSION_MAJOR to {0}' -f $moduleInfo.ModuleMajorVersion)
        } catch {
            Write-Host 'Error updating PSFY_MODULE_VERSION_MAJOR: {0}' -f $_.Exception.Message
        }
        Write-Host 'Updating moduleinfo.json'
        $header = @{
            'PRIVATE-TOKEN' = $env:PSFY_PROJECT_TOKEN
            'Content-Type' = 'application/json'
        }
        $moduleInfoContent | ConvertTo-Json -Compress
        $body = @{
            'branch' = $env:CI_MERGE_REQUEST_SOURCE_BRANCH_NAME
            'author_email' = $env:GITLAB_USER_EMAIL
            'author_name' = $env:GITLAB_USER_NAME
            'content' = $moduleInfoContent
            'commit_message' = 'Update moduleinfo.json for versioning'
        } | ConvertTo-Json -Compress
        $apiURL = ('{0}/projects/{1}/repository/files/moduleinfo%2Ejson' -f $env:CI_API_V4_URL, $env:CI_PROJECT_ID)
        try {
            $res = Invoke-RestMethod -Uri $apiURL -Method Put -Headers $header -Body $body -Verbose:$false -EA Stop
            Write-Host 'Updated moduleinfo.json'
        } catch {
            Write-Host ('Error updating moduleinfo.json: {0}' -f $_.Exception.Message)
        }
    } else {
        Write-Host 'Will not increment version because the version parts in PSFY_MODULE_VERSION_* variables are missing or non-integer OR too early in the merge process'
    }
}
$moduleManifestName = Join-Path -Path $outputFolder -ChildPath ('{0}.psd1' -f $moduleInfo.ModuleName)
$moduleBodyName = Join-Path -Path $outputFolder -ChildPath ('{0}.psm1' -f $moduleInfo.ModuleName)
$lines = New-Object System.Collections.Generic.List[string]
$functions = New-Object System.Collections.Generic.List[string]
$curFile = Join-Path -Path $partsFolder -ChildPath '_header.ps1'
if (Test-Path -Path $curFile -PathType Leaf) {
    Write-Host 'Processing header'
    foreach ($line in (Get-Content -Path $curFile)) {
        $null = $lines.Add($line)
    }
}

$privateFolder = Join-Path -Path $partsFolder -ChildPath 'private'
if (Test-Path -Path $privateFolder -PathType Container) {
    foreach ($file in (Get-ChildItem -Path $privateFolder -Filter '*.ps1')) {
        Write-Host ('Processing private insert {0}' -f $file.Name)
        $curFile = $file.FullName
        foreach ($line in (Get-Content -Path $curFile)) {
            $null = $lines.Add($line)
        }
    }
}

$publicFolder = Join-Path -Path $partsFolder -ChildPath 'public'
if (Test-Path -Path $publicFolder -PathType Container) {
    foreach ($file in (Get-ChildItem -Path $publicFolder -Filter '*.ps1')) {
        Write-Host ('Processing public insert {0}' -f $file.Name)
        $curFile = $file.FullName
        foreach ($line in (Get-Content -Path $curFile)) {
            $null = $lines.Add($line)
        }
        $funcs = (Get-Command $curFile).ScriptBlock.Ast.FindAll(
            { $args[0] -is [System.Management.Automation.Language.FunctionDefinitionAst] },$false 
        ).Name
        foreach ($func in $funcs) {
            Write-Host ('Adding function {0}' -f $func)
            $null = $functions.Add($func)
        }
    }
}

$curFile = Join-Path -Path $partsFolder -ChildPath '_footer.ps1'
if (Test-Path -Path $curFile -PathType Leaf) {
    Write-Host 'Processing footer'
    foreach ($line in (Get-Content -Path $curFile)) {
        $null = $lines.Add($line)
    }
}
if ($functions.Count -gt 0) {
    $null = $lines.Add(('Export-ModuleMember -Function @(''{0}'')' -f ($functions -join ''', ''')))
}
try {
    $lines | Set-Content -Path $moduleBodyName -Encoding UTF8 -Force -EA Stop
} catch {
    exit 3
}
$manifestData = @{
    ModuleVersion = ('{0}.{1}.{2}' -f $moduleInfo.ModuleMajorVersion, $moduleInfo.ModuleMinorVersion, $moduleInfo.ModulePatch)
    GUID = $moduleInfo.ModuleGUID
    Author = $moduleAuthor
    CompanyName = $companyName
    Copyright = ('{0} {1}' -f [datetime]::Now.Year, $companyName)
    Description = $moduleInfo.Description
	HelpInfoURI = 'https://psfactory.wtf-it.com/powershell'
    ProjectURI = 'https://psfactory.wtf-it.com/powershell'
    PowerShellVersion = '5.1'
    CompatiblePSEditions = 'Desktop'
    Path = $moduleManifestName
    RootModule = ('{0}.psm1' -f $moduleInfo.ModuleName)
    NestedModules = @()
    RequiredModules = $moduleInfo.RequiredModules
    FunctionsToExport = $functions
    CmdletsToExport = @()
    VariablesToExport = @()
    DefaultCommandPrefix = ''
    PrivateData = @{}
}

Write-Host 'Building module manifest'
New-ModuleManifest @manifestData
