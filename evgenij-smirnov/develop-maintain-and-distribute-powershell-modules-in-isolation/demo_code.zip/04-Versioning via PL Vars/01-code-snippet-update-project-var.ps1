<#
    Building and distributing modules in isolation

    PSConfEU 2026 | Wiesbaden, Germany

    Evgenij Smirnov @it-pro-berlin.de
    
    This is how you update project variables using GitLab API and a project token
#>
$apiURL = ('{0}/projects/{1}/variables/{2}' -f $env:CI_API_V4_URL, $env:CI_PROJECT_ID,'MODULE_VERSION_PATCH')
Write-Host "API URL: $apiURL"
Write-Host "Old value: $env:PSFY_MODULE_VERSION_PATCH "
$newValue = $env:PSFY_MODULE_VERSION_PATCH -as [int]
if ($null -eq $newValue) {
    Write-Host "Not convertible to int"
} else {
    $newValue++
    Write-Host "New value: $newValue"
    $header = @{
        'PRIVATE-TOKEN' = $env:PSFY_UPDATE_TOKEN
    }
    $form = @{
        'value' = $newValue
    }
    $res = Invoke-RestMethod -Uri $apiURL -Method Put -Headers $header -Form $form
    Write-Host $res
}