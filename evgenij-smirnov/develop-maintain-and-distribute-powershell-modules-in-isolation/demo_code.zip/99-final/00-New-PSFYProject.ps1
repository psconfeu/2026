<#
    Building and distributing modules in isolation

    PSConfEU 2026 | Wiesbaden, Germany

    Evgenij Smirnov @it-pro-berlin.de
    
    Scaffolding a GitLab project for a PowerShell module

    All files that get provisioned into the new repository
    are included in the script to make it self-contained 
    and potentially signable.
    
    Wouldn't it be a great idea to have a GitLab project
    for this script, too? ;-)

    The project token generation via API stopped working a couple of weeks ago.
    If/when I figure out how to get it to work again, I will update this.
#>
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$false)]
    [string]$PersonalToken,
    [Parameter(Mandatory=$false)]
    [string]$Namespace = 'Playground',
    [Parameter(Mandatory=$false)]
    [string]$BaseUrl = 'https://psfactory.wtf-it.com/',
    [Parameter(Mandatory=$false)]
    [string]$LocalRepoBase,
    [Parameter(Mandatory=$true)]
    [string]$ModuleName,
    [Parameter(Mandatory=$false)]
    [string]$ModuleDescription
)
#region init
$header = @{
    'PRIVATE-TOKEN' = $PersonalToken
}
$apiBase = ('{0}/api/v4/' -f $BaseUrl.TrimEnd('\/'))
$nsId = $null
$nsSlug = $null
$psfyModuleName = $ModuleName -replace '\s'
Write-Verbose ('Module name will be: {0}' -f $psfyModuleName)
$psfyProjectSlug = ($ModuleName -replace '\s','-').ToLower()
Write-Verbose ('Project slug will be: {0}' -f $psfyProjectSlug)
$psfyModuleGUID = [Guid]::NewGuid().Guid
Write-Verbose ('Moduel GUID will be: {0}' -f $psfyModuleGUID)
$psfyProjectId = $null
#endregion
#region scripts and scaffold
#region module-info-json
$module_info = @{
    'ModuleName' = $psfyModuleName
    'ModuleGUID' = $psfyModuleGUID
    'ModuleMajorVersion' = 99
    'ModuleMinorVersion' = 99
    'ModulePatch'  = 999
    'Description' = $ModuleDescription
    'RequiredModules' = @()
} | ConvertTo-Json
#endregion
#region module-header
$module_header = @'
<#

Module header

Created by PSFactory

#>
'@
#endregion
#region module-footer
$module_footer = @'
<#

Module footer

Created by PSFactory

#>
'@
#endregion
#region sample-private-function
$private_func = @'
function Test-RunElevated {
    [CmdletBinding()]
    Param()
    return ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}
'@
#endregion
#region sample-public-function
$public_func = @'
function Invoke-Nothing {
    [CmdletBinding()]
    Param()
    return $null
}
'@
#endregion
#region test-job-script
$test_script = @'
# I am a test script
'@
#endregion
#region build-job-script
$build_script = @'
$companyName = 'WTF IT, Inc.'
$moduleAuthor = 'Alice and Bob'
$partsFolder = Join-Path -Path $PSScriptRoot -ChildPath 'parts'
if (-not (Test-Path -Path $partsFolder -PathType Container)) {
    Write-Host 'Parts container not found!'
    exit 1
}
if ([string]::IsNullOrWhiteSpace($env:PSFY_MODULE_NAME) -or [string]::IsNullOrWhiteSpace($env:PSFY_MODULE_GUID)) {
    Write-Host 'Pipeline variables not initialized, running from local moduleinfo.json'
    $jsonPath = Join-Path -Path $PSScriptRoot -ChildPath 'moduleinfo.json'
    if (Test-Path -Path $jsonPath -PathType Leaf) {
        $moduleInfo = (Get-Content -Path $jsonPath | ConvertFrom-Json)
    } else {
        Write-Host 'moduleinfo.json not found!'
        exit 1    
    }
} else {
    Write-Host 'Running within a pipeline'
    $moduleInfo = [PSCustomObject]@{
        'ModuleName' = $env:PSFY_MODULE_NAME
        'ModuleGUID' = $env:PSFY_MODULE_GUID
        'ModuleMajorVersion' = 99
        'ModuleMinorVersion' = 99
        'ModulePatch' = 999
        'Description' = $env:PSFY_MODULE_DESC
        'RequiredModules' = @()
    }
}
$outputFolder = Join-Path -Path $PSScriptRoot -ChildPath $moduleInfo.ModuleName
if (-not (Test-Path -Path $outputFolder -PathType Any)) {
    try {
        $null = New-Item -Path $outputFolder -ItemType Directory -Force -EA Stop
    } catch {
        Write-Host 'Error creating output folder: {0}' -f $_.Exception.Message
        exit 2
    }
}
if (-not ([string]::IsNullOrWhiteSpace($env:PSFY_MODULE_NAME) -or [string]::IsNullOrWhiteSpace($env:PSFY_MODULE_GUID))) {
    $doIncrement = $true
    Write-Host ('Major version from pipeline: {0}' -f $env:PSFY_MODULE_VERSION_MAJOR)
    if ($null -eq ($env:PSFY_MODULE_VERSION_MAJOR -as [int])) {
        Write-Host 'Not convertible to integer, setting to 99'
    } else {
        $moduleInfo.ModuleMajorVersion = ($env:PSFY_MODULE_VERSION_MAJOR -as [int])
    }
    Write-Host ('Minor version from pipeline: {0}' -f $env:PSFY_MODULE_VERSION_MINOR)
    if ($null -eq ($env:PSFY_MODULE_VERSION_MINOR -as [int])) {
        Write-Host 'Not convertible to integer, setting to 99'
    } else {
        $moduleInfo.ModuleMinorVersion = ($env:PSFY_MODULE_VERSION_MINOR -as [int])
    }
    Write-Host ('Patch version from pipeline: {0}' -f $env:PSFY_MODULE_VERSION_PATCH)
    if ($null -eq ($env:PSFY_MODULE_VERSION_PATCH -as [int])) {
        Write-Host 'Not convertible to integer, setting to 999'
    } else {
        $moduleInfo.ModulePatch = ($env:PSFY_MODULE_VERSION_PATCH -as [int])
    }
    if ($doIncrement) {
        Write-Host ('Pipeline source: {0}' -f $env:CI_PIPELINE_SOURCE)
        Write-Host ('Source branch: {0}' -f $env:CI_MERGE_REQUEST_SOURCE_BRANCH_NAME)
        Write-Host ('Target branch: {0}' -f $env:CI_MERGE_REQUEST_TARGET_BRANCH_NAME)
        Write-Host ('Commit branch: {0}' -f $env:CI_COMMIT_BRANCH)
        if ([string]::IsNullOrWhiteSpace($env:PSFY_PROJECT_TOKEN)) {
            Write-Host 'Cannot increment version because PSFY_PROJECT_TOKEN is missing'
            $doIncrement = $false
        }
        if ($env:CI_PIPELINE_SOURCE -ne 'merge_request_event') {
            Write-Host 'Cannot increment version because this run is not on a merge request'
            $doIncrement = $false
        }
    } else {
        Write-Host 'Not all pipeline variables had correct values'
    }
    if ($doIncrement) {
        if ($env:CI_MERGE_REQUEST_SOURCE_BRANCH_NAME -match '^major\/') {
            Write-Host ('Increasing the major version from {0}, resetting minor and patch' -f $moduleInfo.ModuleMajorVersion)
            $moduleInfo.ModuleMajorVersion++
            $moduleInfo.ModuleMinorVersion = 0
            $moduleInfo.ModulePatch = 0
        } elseif ($env:CI_MERGE_REQUEST_SOURCE_BRANCH_NAME -match '^minor\/') {
            Write-Host ('Increasing the minor version from {0}, resetting patch' -f $moduleInfo.ModuleMinorVersion)
            $moduleInfo.ModuleMinorVersion++
            $moduleInfo.ModulePatch = 0
        } else {
            Write-Host ('Increasing the patch from {0}' -f $moduleInfo.ModulePatch)
            $moduleInfo.ModulePatch++
        }
        $header = @{
            'PRIVATE-TOKEN' = $env:PSFY_PROJECT_TOKEN
        }
        $apiURL = ('{0}/projects/{1}/variables/{2}' -f $env:CI_API_V4_URL, $env:CI_PROJECT_ID,'PSFY_MODULE_VERSION_PATCH')
        $form = @{
            'value' = $moduleInfo.ModulePatch
        }
        try {
            $res = Invoke-RestMethod -Uri $apiURL -Method Put -Headers $header -Form $form -Verbose:$false -EA Stop
            Write-Host ('Updated PSFY_MODULE_VERSION_PATCH to {0}' -f $moduleInfo.ModulePatch)
        } catch {
            Write-Host 'Error updating PSFY_MODULE_VERSION_PATCH: {0}' -f $_.Exception.Message
        }
        $apiURL = ('{0}/projects/{1}/variables/{2}' -f $env:CI_API_V4_URL, $env:CI_PROJECT_ID,'PSFY_MODULE_VERSION_MINOR')
        $form = @{
            'value' = $moduleInfo.ModuleMinorVersion
        }
        try {
            $res = Invoke-RestMethod -Uri $apiURL -Method Put -Headers $header -Form $form -Verbose:$false -EA Stop
            Write-Host ('Updated PSFY_MODULE_VERSION_MINOR to {0}' -f $moduleInfo.ModuleMinorVersion)
        } catch {
            Write-Host 'Error updating PSFY_MODULE_VERSION_MINOR: {0}' -f $_.Exception.Message
        }
        $apiURL = ('{0}/projects/{1}/variables/{2}' -f $env:CI_API_V4_URL, $env:CI_PROJECT_ID,'PSFY_MODULE_VERSION_MAJOR')
        $form = @{
            'value' = $moduleInfo.ModuleMajorVersion
        }
        try {
            $res = Invoke-RestMethod -Uri $apiURL -Method Put -Headers $header -Form $form -Verbose:$false -EA Stop
            Write-Host ('Updated PSFY_MODULE_VERSION_MAJOR to {0}' -f $moduleInfo.ModuleMajorVersion)
        } catch {
            Write-Host 'Error updating PSFY_MODULE_VERSION_MAJOR: {0}' -f $_.Exception.Message
        }
        Write-Host 'Updating moduleinfo.json'
        $header = @{
            'PRIVATE-TOKEN' = $env:PSFY_PROJECT_TOKEN
            'Content-Type' = 'application/json'
        }
        $moduleInfoContent | ConvertTo-Json -Compress
        $body = @{
            'branch' = $env:CI_MERGE_REQUEST_SOURCE_BRANCH_NAME
            'author_email' = $env:GITLAB_USER_EMAIL
            'author_name' = $env:GITLAB_USER_NAME
            'content' = $moduleInfoContent
            'commit_message' = 'Update moduleinfo.json for versioning'
        } | ConvertTo-Json -Compress
        $apiURL = ('{0}/projects/{1}/repository/files/moduleinfo%2Ejson' -f $env:CI_API_V4_URL, $env:CI_PROJECT_ID)
        try {
            $res = Invoke-RestMethod -Uri $apiURL -Method Put -Headers $header -Body $body -Verbose:$false -EA Stop
            Write-Host 'Updated moduleinfo.json'
        } catch {
            Write-Host ('Error updating moduleinfo.json: {0}' -f $_.Exception.Message)
        }
    } else {
        Write-Host 'Will not increment version because the version parts in PSFY_MODULE_VERSION_* variables are missing or non-integer OR too early in the merge process'
    }
}
$moduleManifestName = Join-Path -Path $outputFolder -ChildPath ('{0}.psd1' -f $moduleInfo.ModuleName)
$moduleBodyName = Join-Path -Path $outputFolder -ChildPath ('{0}.psm1' -f $moduleInfo.ModuleName)
$lines = New-Object System.Collections.Generic.List[string]
$functions = New-Object System.Collections.Generic.List[string]
$curFile = Join-Path -Path $partsFolder -ChildPath '_header.ps1'
if (Test-Path -Path $curFile -PathType Leaf) {
    Write-Host 'Processing header'
    foreach ($line in (Get-Content -Path $curFile)) {
        $null = $lines.Add($line)
    }
}

$privateFolder = Join-Path -Path $partsFolder -ChildPath 'private'
if (Test-Path -Path $privateFolder -PathType Container) {
    foreach ($file in (Get-ChildItem -Path $privateFolder -Filter '*.ps1')) {
        Write-Host ('Processing private insert {0}' -f $file.Name)
        $curFile = $file.FullName
        foreach ($line in (Get-Content -Path $curFile)) {
            $null = $lines.Add($line)
        }
    }
}

$publicFolder = Join-Path -Path $partsFolder -ChildPath 'public'
if (Test-Path -Path $publicFolder -PathType Container) {
    foreach ($file in (Get-ChildItem -Path $publicFolder -Filter '*.ps1')) {
        Write-Host ('Processing public insert {0}' -f $file.Name)
        $curFile = $file.FullName
        foreach ($line in (Get-Content -Path $curFile)) {
            $null = $lines.Add($line)
        }
        $funcs = (Get-Command $curFile).ScriptBlock.Ast.FindAll(
            { $args[0] -is [System.Management.Automation.Language.FunctionDefinitionAst] },$false 
        ).Name
        foreach ($func in $funcs) {
            Write-Host ('Adding function {0}' -f $func)
            $null = $functions.Add($func)
        }
    }
}

$curFile = Join-Path -Path $partsFolder -ChildPath '_footer.ps1'
if (Test-Path -Path $curFile -PathType Leaf) {
    Write-Host 'Processing footer'
    foreach ($line in (Get-Content -Path $curFile)) {
        $null = $lines.Add($line)
    }
}
if ($functions.Count -gt 0) {
    $null = $lines.Add(('Export-ModuleMember -Function @(''{0}'')' -f ($functions -join ''', ''')))
}
try {
    $lines | Set-Content -Path $moduleBodyName -Encoding UTF8 -Force -EA Stop
} catch {
    exit 3
}
$manifestData = @{
    ModuleVersion = ('{0}.{1}.{2}' -f $moduleInfo.ModuleMajorVersion, $moduleInfo.ModuleMinorVersion, $moduleInfo.ModulePatch)
    GUID = $moduleInfo.ModuleGUID
    Author = $moduleAuthor
    CompanyName = $companyName
    Copyright = ('{0} {1}' -f [datetime]::Now.Year, $companyName)
    Description = $moduleInfo.Description
	HelpInfoURI = 'https://psfactory.wtf-it.com/powershell'
    ProjectURI = 'https://psfactory.wtf-it.com/powershell'
    PowerShellVersion = '5.1'
    CompatiblePSEditions = 'Desktop'
    Path = $moduleManifestName
    RootModule = ('{0}.psm1' -f $moduleInfo.ModuleName)
    NestedModules = @()
    RequiredModules = $moduleInfo.RequiredModules
    FunctionsToExport = $functions
    CmdletsToExport = @()
    VariablesToExport = @()
    DefaultCommandPrefix = ''
    PrivateData = @{}
}

Write-Host 'Building module manifest'
New-ModuleManifest @manifestData
'@
#endregion
#region sign-job-script
$sign_script = @'
$certCandidates = (Get-ChildItem Cert:\LocalMachine\My).Where({$_.HasPrivateKey -and  $_.EnhancedKeyUsageList.ObjectId -contains '1.3.6.1.5.5.7.3.3'})
if ($certCandidates.Count -eq 0) {
    Write-Host 'No signing certificate found'
    exit 3
}
$cert = ($certCandidates | Sort-Object NotAfter -Descending)[0]
Write-Host ('Selected Cert: [{2}] {0} by {1}' -f $cert.Subject, $cert.Issuer, $cert.Thumbprint)
if ([string]::IsNullOrWhiteSpace($env:PSFY_MODULE_NAME)) {
    Write-Host 'Module name not passed from pipeline'
    exit 7
}
$outputFolder = Join-Path -Path $PSScriptRoot -ChildPath $env:PSFY_MODULE_NAME
if (-not (Test-Path -Path $outputFolder -PathType Any)) {
    Write-Host 'Output folder not found'
    exit 2
}
$moduleManifestName = Join-Path -Path $outputFolder -ChildPath ('{0}.psd1' -f $env:PSFY_MODULE_NAME)
$moduleBodyName = Join-Path -Path $outputFolder -ChildPath ('{0}.psm1' -f $env:PSFY_MODULE_NAME)
Set-AuthenticodeSignature -Certificate $cert -FilePath $moduleManifestName
Set-AuthenticodeSignature -Certificate $cert -FilePath $moduleBodyName
'@
#endregion
#region pack-job-script
$pack_script = @'
$rc = 0
$nuGetPath = 'C:\gitlab\nuget.exe'
if (-not (Test-Path -Path $nuGetPath)) {
    Write-Host 'NuGet not found in required location'
    $nuGetSourcePath = 'C:\gitlab\NuGet.exe'
    if (Test-Path -Path $nuGetSourcePath) {
        Write-Host 'Copying NuGet'
        try {
            Copy-Item -Path $nuGetSourcePath -Destination $nuGetPath -Force -EA Stop
        } catch {
            Write-Host $_.Exception.Message
            exit 666
        }
    }
} else {
    Write-Host 'NuGet found'
}

if ([string]::IsNullOrWhiteSpace($env:PSFY_MODULE_NAME) -or [string]::IsNullOrWhiteSpace($env:PSFY_MODULE_GUID)) {
    Write-Host 'Pipeline variables not initialized, running from local moduleinfo.json'
    $jsonPath = Join-Path -Path $PSScriptRoot -ChildPath 'moduleinfo.json'
    if (Test-Path -Path $jsonPath -PathType Leaf) {
        $moduleInfo = (Get-Content -Path $jsonPath | ConvertFrom-Json)
    } else {
        Write-Host 'moduleinfo.json not found!'
        exit 1    
    }
} else {
    $moduleInfo = [PSCustomObject]@{
        'ModuleName' = $env:PSFY_MODULE_NAME
        'ModuleGUID' = $env:PSFY_MODULE_GUID
        'ModuleMajorVersion' = ($env:PSFY_MODULE_VERSION_MAJOR -as [int])
        'ModuleMinorVersion' = ($env:PSFY_MODULE_VERSION_MINOR -as [int])
        'ModulePatch' = ($env:PSFY_MODULE_VERSION_PATCH -as [int])
        'Description' = $env:PSFY_MODULE_DESC
        'RequiredModules' = @()
    }
    if ($null -eq $moduleInfo.ModuleMajorVersion) { $moduleInfo.ModuleMajorVersion = 99 }
    if ($null -eq $moduleInfo.ModuleMinorVersion) { $moduleInfo.ModuleMinorVersion = 99 }
    if ($null -eq $moduleInfo.ModulePatch) { $moduleInfo.ModulePatch = 999 }
}

$reponame = ('repo{0}' -f (Get-Date -Format 'yyyyMMddHHmmss'))
$repopath = Join-Path -Path $PSScriptRoot -ChildPath 'nuget-package'
if (-not (Test-Path -Path $repopath)) {
    Write-Host 'Creating artifact path'
    $null = New-Item -Path $repopath -ItemType Directory -Force
}
$exrepo = Get-PSRepository | Where-Object SourceLocation -eq $repopath
if ($null -eq $exrepo) {
    Write-Host ('Registering {0} as repository {1}' -f $repopath, $reponame)
    try {
        Register-PSRepository -Name $reponame -SourceLocation $repopath -PublishLocation $repopath -PackageManagementProvider NuGet -EA Stop
    } catch {
        Write-Host $_.Exception.Message
        exit 1
    }
} else {
    $reponame = $exrepo.Name
    Write-Host ('Reusing existing repository {0}' -f $reponame)
}

$outputFolder = Join-Path -Path $PSScriptRoot -ChildPath $moduleInfo.ModuleName
if (Test-Path -Path $outputFolder) {
    Write-Host ('Publishing module from {0}' -f $outputFolder)
    try {
        Publish-Module -Path $outputFolder -Repository $reponame -Force -Confirm:$false -EA Stop
    } catch {
        Write-Host $_.Exception.Message
        exit 3
    }
} else {
    Write-Host 'Module output folder not found'
    $rc = 4
}
try {
    Unregister-PSRepository -Name $reponame -EA Stop
} catch {}
exit $rc
'@
#endregion
#region publish-job-script
$publish_script = @'
$rc = 0
$apiKey = $env:PSFY_DEPLOY_TOKEN
$projectID = $env:PSFY_DEPLOY_PROJECT_ID
if ([string]::IsNullOrWhiteSpace($env:PSFY_DEPLOY_TOKEN) -or [string]::IsNullOrWhiteSpace($env:PSFY_DEPLOY_PROJECT_ID)) {
    Write-Host 'Pipeline variables not set!'
    exit 7
}
Write-Host ('Pushing package for project ID {0} with API Key {1}' -f $projectID, $apiKey)
$repopath = Join-Path -Path $PSScriptRoot -ChildPath 'nuget-package'
if (-not (Test-Path -Path $repopath)) {
    Write-Host 'Artifact folder not found'
    exit 1
}
$pkgs = @(Get-ChildItem -Path $repopath -File -Filter '*.nupkg')
if ($pkgs.Count -eq 0) {
    Write-Host 'Artifact not found'
    exit 2
}
$pkg = $pkgs[0]
Write-Host ('Will push {0}' -f $pkg.FullName)
try {
    Write-Host 'Removing existing source'
    C:\gitlab\nuget.exe source remove -Name gitlab-temp
} catch {
    Write-Host $_.Exception.Message
}
try {
    Write-Host 'Setting API Key'
    C:\gitlab\nuget.exe setapikey $apiKey -source "https://psfactory.wtf-it.com/api/v4/projects/$($projectID)/packages/nuget/index.json"
} catch {
    Write-Host $_.Exception.Message
}
Write-Host 'Adding NuGet Source'
C:\gitlab\nuget.exe source Add -Name gitlab-temp -Source "https://psfactory.wtf-it.com/api/v4/projects/$($projectID)/packages/nuget/index.json" #-UserName "alice@wtf-it.com" -Password "glpat-0X_OXmLeDvyRLxaGiBDvlm86MQp1OjkH.01.0w1thqehf"
Write-Host 'Pushing package'
C:\gitlab\nuget.exe push $pkg.FullName -Source gitlab-temp
$rc = $LASTEXITCODE
try {
    Write-Host 'Cleaning up source'
    C:\gitlab\nuget.exe source remove -Name gitlab-temp
} catch {
    Write-Host $_.Exception.Message
}
exit $rc
'@

$gitlab_cicd = @'
stages:          # List of stages for jobs, and their order of execution
  - dummy
  - test
  - build
  - sign
  - publish

dummy-job:      # This job runs on merge request creation
  stage: dummy
  script:
    - echo "Dummy step"
  rules:
    - if: $CI_PIPELINE_SOURCE == "merge_request_event"
      when: always

test-job:       # This job runs in the test stage, on merge request creation only. If this fails, merge request cannot be merged.
  stage: test
  script:
    - echo "Testing the code..."
    - '& .\test.ps1'
    - echo "Test complete."
  rules:
    - if: ($CI_PIPELINE_SOURCE == "merge_request_event" && $CI_MERGE_REQUEST_SOURCE_BRANCH_NAME != "scaffold")
      when: always

build-job:       # This job runs in the build stage, on merge request creation only. It runs only if the tests are successful. If this fails, merge request cannot be merged.
  stage: build
  dependencies:
    - test-job
  script:
    - echo "Building the code..."
    - '& .\build.ps1'
    - echo "Build complete."
  rules:
    - if: ($CI_PIPELINE_SOURCE == "merge_request_event" && $CI_MERGE_REQUEST_TARGET_BRANCH_NAME == "main" && $CI_MERGE_REQUEST_SOURCE_BRANCH_NAME != "scaffold")
      when: always

build-on-merge:       # This job runs in the build stage on a merge. This assumes that the tests were successful, otherwise we would not be here
  stage: build
  script:
    - echo "Building the code..."
    - '& .\build.ps1'
    - echo "Build complete."
  rules:
    - if: ($CI_PIPELINE_SOURCE == "push" && $CI_COMMIT_BRANCH == "main")
      when: always
  artifacts:
    paths:
      - {0}/

sign-job:           # This job runs in the sign stage, which is dependent on build.
  stage: sign
  dependencies:
    - build-on-merge
  script:
    - echo "Signing the artifacts"
    - '& .\sign.ps1'
    - echo "Signing complete."
  rules:
    - if: ($CI_PIPELINE_SOURCE == "push" && $CI_COMMIT_BRANCH == "main")
      when: always
  artifacts:
    paths:
      - {0}/

publish-job:       # This job runs in the publish stage, which is dependent on sign.
  stage: publish
  dependencies:
    - sign-job
  script:
    - echo "Creating the package"
    - '& .\pack.ps1'
    - echo "Package created. Publishing package"
    - '& .\publish.ps1'
    - echo "Package published."
  rules:
    - if: ($CI_PIPELINE_SOURCE == "push" && $CI_COMMIT_BRANCH == "main")
      when: always
  artifacts:
    paths:
      - nuget-package/
'@ -f $psfyModuleName
#endregion
#region check for namespace existence and details
$url = ('{0}namespaces/{1}/exists' -f $apiBase, $Namespace)
try {
    $apires = Invoke-RestMethod -Uri $url -Method Get -Headers $header -EA Stop -Verbose:$false
    if (-not $apires.exists) {
        Write-Warning ('Namespace does not exist: {0}' -f $Namespace)
        exit
    }
} catch {
    Write-Warning ('Error checking for namespace existence: {0}' -f $_.Exception.Message)
}
Write-Verbose ('Namespace exists: {0}' -f $Namespace)
$url = ('{0}namespaces/{1}' -f $apiBase, $Namespace)
try {
    $apires = Invoke-RestMethod -Uri $url -Method Get -Headers $header -EA Stop -Verbose:$false
    Write-Verbose ('Namespace of kind "{1}" exists with id {0}' -f $apires.id, $apires.kind)
    $nsId = $apires.id
    $nsSlug = $apires.path
} catch {
    Write-Warning ('Error getting namespace details: {0}' -f $_.Exception.Message)
}
#endregion
#region ensure local folders exist
if ([string]::IsNullOrWhiteSpace($LocalRepoBase)) {
    $localBasePath = Join-Path -Path ([Environment]::GetFolderPath('MyDocuments')) -ChildPath 'CODE'
} else {
    $localBasePath = $LocalRepoBase
}
if (-not (Test-Path -Path $localBasePath)) {
    try {
        $null = New-Item -Path $localBasePath -ItemType Directory -Force -EA Stop
        Write-Verbose ('Base path created: {0}' -f $localBasePath)
    } catch {
        Write-Warning ('Could not create local base path: {0}; the error was: {1}' -f $localBasePath, $_.Exception.Message)
        exit
    }
} else {
    Write-Verbose ('Base path exists: {0}' -f $localBasePath)
}
$localNamespacePath = Join-Path -Path $localBasePath -ChildPath $Namespace
if (-not (Test-Path -Path $localNamespacePath)) {
    try {
        $null = New-Item -Path $localNamespacePath -ItemType Directory -Force -EA Stop
        Write-Verbose ('Namespace path created: {0}' -f $localNamespacePath)
    } catch {
        Write-Warning ('Could not create namespace path: {0}; the error was: {1}' -f $localNamespacePath, $_.Exception.Message)
        exit
    }
} else {
    Write-Verbose ('Namespace path exists: {0}' -f $localNamespacePath)
}
#endregion
#region check for project existence
$url = ('{0}projects?search={1}' -f $apiBase, $psfyProjectSlug)
try {
    $apires = Invoke-RestMethod -Uri $url -Method Get -Headers $header -EA Stop -Verbose:$false
    Write-Verbose ('Search for {0} yielded {1} results' -f $psfyProjectSlug, $apires.Count)
    foreach ($proj in $apires) {
        if ($proj.path -ne $psfyProjectSlug) { continue }
        if ($proj.namespace.id -ne $nsId) {
            Write-Warning ('Project found in a different namespace: {0}' -f $proj.namespace.name)
        } else {
            Write-Warning 'Project already exists in namespace'
        }
        exit
    }
} catch {
    Write-Warning ('Error searching for projects: {0}' -f $_.Exception.Message)
    exit
}
$localProjectPath = (Join-Path -Path $localNamespacePath -ChildPath $psfyProjectSlug)
if (Test-Path -Path $localProjectPath) {
    Write-Warning ('Local project path already exists: {0}' -f $localProjectPath)
    exit
}
#endregion
#regioon create a project
$url = ('{0}projects' -f $apiBase)
$body = @{
    'name' = $ModuleName
    'path' = $psfyProjectSlug
    'description' = $ModuleDescription
    'namespace_id' = $nsId
    'initialize_with_readme' = $true
}
try {
    $apires = Invoke-RestMethod -Uri $url -Method Post -Headers $header -Body $body -EA Stop -Verbose:$false
    $psfyProjectId = $apires.id
    $gitCloneUrl = $apires.http_url_to_repo   
    Write-Host ('Created project {0} with ID {1}' -f $apires.path, $psfyProjectId)
} catch {
    Write-Warning ('Error creating project: {0}' -f $_.Exception.Message)
    exit
}
#endregion
#region create access token
$psfyProjectToken = 'ZZZZYYYYXXXX'
$prATCreated = $false
$url = ('{0}projects/{1}/access_tokens' -f $apiBase, $psfyProjectId)
$body = @{
    'id' = $psfyProjectId
    'name' = 'APIAccessToken'
    'description' = 'Token used in pipelines to increment versions and perform other write operations'
    'access_level' = 40 # maintainer
    'scopes' = @()#'api','read_repository','write_repository','self_rotate')
    'expires_at' = ('{0:yyyy-MM-dd}' -f [datetime]::Now.AddDays(364))
}
try {
    $apires = Invoke-RestMethod -Uri $url -Method Post -Headers $header -Body $body -EA Stop -Verbose:$false
    $psfyProjectToken = $apires.token
    Write-Verbose 'Access Token created'
    $prATCreated = $true
} catch {
    Write-Warning ('Error creating access token: {0}' -f $_.Exception.Message)
}
if (-not $prATCreated) {
    $psfyProjectToken = $PersonalToken
}
#endregion
#region create and populate module specifics
$url = ('{0}projects/{1}/variables' -f $apiBase, $psfyProjectId)
$vars = [ordered]@{
    'PSFY_MODULE_GUID' = $psfyModuleGUID
    'PSFY_MODULE_NAME' = $psfyModuleName
    'PSFY_MODULE_DESC' = $ModuleDescription
    'PSFY_MODULE_VERSION_MAJOR' = '0'
    'PSFY_MODULE_VERSION_MINOR' = '0'
    'PSFY_MODULE_VERSION_PATCH' = '1'
    'PSFY_PROJECT_TOKEN' = $psfyProjectToken
}
foreach ($var in $vars.GetEnumerator()) {
    if ($var.Name -notmatch 'TOKEN') {
        $body = @{
            'id' = $psfyProjectId
            'key' = $var.Name
            'value' = $var.Value
        }
        $showValue = $var.Value
    } else {
        $body = @{
            'id' = $psfyProjectId
            'key' = $var.Name
            'value' = $var.Value
            'masked' = $true
        }
        $showValue = '***'
    }
    try {
        $apires = Invoke-RestMethod -Uri $url -Method Post -Headers $header -Body $body -EA Stop -Verbose:$false
        Write-Verbose ('Added variable {0} with value {1}' -f $var.Name, $showValue)
    } catch {
        Write-Warning ('Error adding variable to project: {0}' -f $_.Exception.Message)
    }
}
#endregion
#region pulling the initial state
Push-Location
Set-Location -Path $localNamespacePath
$gitConeCommand = ('git clone {0} 2>&1' -f ($gitCloneUrl -replace 'https\:\/\/',('https://token:{0}@' -f $PersonalToken)))
$res = Invoke-Expression $gitConeCommand
#endregion
#region adding scaffold
if (-not (Test-Path -Path $localProjectPath)) {
    Write-Warning ('Local project path not created after git clone: {0}' -f $localProjectPath)
    exit
}
Set-Location -Path $localProjectPath
$res = Invoke-Expression 'git checkout -b scaffold 2>&1'
Write-Verbose 'Created scaffold branch'
$null = New-Item -Path $localProjectPath -Name 'parts' -ItemType Directory
$null = New-Item -Path $localProjectPath -Name 'parts/private' -ItemType Directory
$null = New-Item -Path $localProjectPath -Name 'parts/public' -ItemType Directory
Write-Verbose 'Created folder structure'
$module_info | Set-Content -Path (Join-Path -Path $localProjectPath -ChildPath 'moduleinfo.json') -Encoding UTF8
$module_header | Set-Content -Path (Join-Path -Path $localProjectPath -ChildPath 'parts/_header.ps1') -Encoding UTF8
$module_footer | Set-Content -Path (Join-Path -Path $localProjectPath -ChildPath 'parts/_footer.ps1') -Encoding UTF8
$private_func | Set-Content -Path (Join-Path -Path $localProjectPath -ChildPath 'parts/private/Test-RunElevated.ps1') -Force -Encoding UTF8
$public_func | Set-Content -Path (Join-Path -Path $localProjectPath -ChildPath 'parts/public/Invoke-Nothing.ps1') -Force -Encoding UTF8
$test_script | Set-Content -Path (Join-Path -Path $localProjectPath -ChildPath 'test.ps1') -Encoding UTF8
$build_script | Set-Content -Path (Join-Path -Path $localProjectPath -ChildPath 'build.ps1') -Encoding UTF8
$sign_script | Set-Content -Path (Join-Path -Path $localProjectPath -ChildPath 'sign.ps1') -Encoding UTF8
$pack_script | Set-Content -Path (Join-Path -Path $localProjectPath -ChildPath 'pack.ps1') -Encoding UTF8
$publish_script | Set-Content -Path (Join-Path -Path $localProjectPath -ChildPath 'publish.ps1') -Encoding UTF8
$gitlab_cicd | Set-Content -Path (Join-Path -Path $localProjectPath -ChildPath '.gitlab-ci.yml') -Encoding Ascii
#2do migrate from Invoke-Expression because Jordan said so
$res = Invoke-Expression 'git add * 2>&1'
$res = Invoke-Expression 'git commit -m "Module scaffold" 2>&1'
$res = Invoke-Expression 'git push origin scaffold 2>&1'
$res = Invoke-Expression 'git checkout main 2>&1'
$res = Invoke-Expression 'git branch -D scaffold 2>&1'

Write-Verbose 'Sleeping for 5 seconds before creating a merge request...'
Start-Sleep -Seconds 5

$scaffMRID = $null
$url = ('{0}projects/{1}/merge_requests' -f $apiBase, $psfyProjectId)
$body = @{
    'id' = $psfyProjectId
    'source_branch' = 'scaffold'
    'target_branch' = 'main'
    'title' = 'Initial project scaffolding'
}
try {
    $apires = Invoke-RestMethod -Uri $url -Method Post -Headers $header -Body $body -EA Stop -Verbose:$false
    $scaffMRID = $apires.id
    $scaffMRIID = $apires.iid
    Write-Verbose ('Merge request #{0}/{1} created' -f $apires.id, $apires.iid)
} catch {
    Write-Warning ('Error creating merge request: {0}' -f $_.Exception.Message)
}
if ($null -ne $scaffMRID) {
    Write-Verbose 'Sleeping for 10 seconds before approving the merge request...'
    Start-Sleep -Seconds 10

    $header = @{
        'PRIVATE-TOKEN' = $PersonalToken
        'Content-Type' = 'application/json'
    }
    $url = ('{0}projects/{1}/merge_requests/{2}/merge' -f $apiBase, $psfyProjectId, $scaffMRIID)
    $body = @{
        'id' = $psfyProjectId
        'merge_request_iid' = $scaffMRIID
        'should_remove_source_branch' = $true
        'auto_merge' = $true
    } | ConvertTo-JSON
    try {
        $apires = Invoke-RestMethod -Uri $url -Method Put -Headers $header -Body $body -EA Stop -Verbose:$false
        Write-Verbose 'Merged successfully'
        Start-Sleep -Seconds 5
        Write-Verbose 'Pulling main branch back down'
        $res = Invoke-Expression 'git pull origin main 2>&1'
    } catch {
        Write-Warning ('Error merging the merge request: {0}' -f $_.Exception.Message)
    }
}
#endregion
Write-Verbose 'Returning back to previous location'
Pop-Location
if (-not $prATCreated) {
    Write-Host 'WARNING!' -ForegroundColor Yellow
    Write-Host 'Project access token could not be created.' -ForegroundColor Yellow
    Write-Host 'We temporarily put your personal token in the masked variable PSFY_PROJECT_TOKEN so that CI/CD will work for now' -ForegroundColor Yellow
    Write-Host 'Please generate a project token and save it in the masked variable PSFY_PROJECT_TOKEN at your earliest convenience!!!' -ForegroundColor Yellow
}