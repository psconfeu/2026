function Invoke-BoringStuff {
    [CmdletBinding()]
    Param()
    Write-Host "BORING!!"
}