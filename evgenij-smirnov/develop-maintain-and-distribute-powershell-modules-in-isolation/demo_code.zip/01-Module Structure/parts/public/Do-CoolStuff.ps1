function Invoke-CoolStuff {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$true)]
        [string]$Thing
    )
    Write-Host "$Thing IS COOL"
}

function Invoke-CoolStuffAsAdmin {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$true)]
        [string]$Thing
    )
    if (Test-RunElevated) {
        Write-Host "$Thing IS EVEN COOLER AS ADMIN!"
    } else {
        Write-Host "$Thing IS TOTALLY UNCOOL WITHOUT ADMIN RIGHTS!"
    }
}