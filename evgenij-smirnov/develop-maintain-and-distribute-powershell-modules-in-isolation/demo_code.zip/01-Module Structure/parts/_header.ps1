<#
    AdminToys module
#>