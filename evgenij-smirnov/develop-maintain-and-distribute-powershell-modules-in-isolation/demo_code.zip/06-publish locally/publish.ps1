<#
    Building and distributing modules in isolation

    PSConfEU 2026 | Wiesbaden, Germany

    Evgenij Smirnov @it-pro-berlin.de
    
    Sample central publishing script using a globally valid token in the script code.

    Do not do this, use group or project variables instead!!!
#>
$rc = 0
$apiKey = "glpat-IamValidForThePackageRegistryProject"
$projectID = 2
Write-Host ('Pushing package for project ID {0}' -f $projectID)
$repopath = Join-Path -Path $PSScriptRoot -ChildPath 'nuget-package'
if (-not (Test-Path -Path $repopath)) {
    Write-Host 'Artifact folder not found'
    exit 1
}
$pkgs = @(Get-ChildItem -Path $repopath -File -Filter '*.nupkg')
if ($pkgs.Count -eq 0) {
    Write-Host 'Artifact not found'
    exit 2
}
$pkg = $pkgs[0]
Write-Host ('Will push {0}' -f $pkg.FullName)
try {
    Write-Host 'Removing existing source'
    C:\gitlab\nuget.exe source remove -Name gitlab-temp
} catch {
    Write-Host $_.Exception.Message
}
try {
    Write-Host 'Setting API Key'
    C:\gitlab\nuget.exe setapikey $apiKey -source "https://psfactory.wtf-it.com/api/v4/projects/$($projectID)/packages/nuget/index.json"
} catch {
    Write-Host $_.Exception.Message
}
Write-Host 'Adding NuGet Source'
C:\gitlab\nuget.exe source Add -Name gitlab-temp -Source "https://psfactory.wtf-it.com/api/v4/projects/$($projectID)/packages/nuget/index.json" #-UserName "alice@wtf-it.com" -Password "glpat-0X_OXmLeDvyRLxaGiBDvlm86MQp1OjkH.01.0w1thqehf"
Write-Host 'Pushing package'
C:\gitlab\nuget.exe push $pkg.FullName -Source gitlab-temp
$rc = $LASTEXITCODE
try {
    Write-Host 'Cleaning up source'
    C:\gitlab\nuget.exe source remove -Name gitlab-temp
} catch {
    Write-Host $_.Exception.Message
}
exit $rc