<#
    Building and distributing modules in isolation

    PSConfEU 2026 | Wiesbaden, Germany

    Evgenij Smirnov @it-pro-berlin.de
    
    Sample pack script. You do not need to separate packing and publsihing,
    but I wanted to have the NuGet package available as an artifact.
#>
$rc = 0
$nuGetPath = 'C:\ProgramData\Microsoft\Windows\PowerShell\PowerShellGet\NuGet.exe'
if (-not (Test-Path -Path $nuGetPath)) {
    Write-Host 'NuGet not found in required location'
    $nuGetSourcePath = 'C:\gitlab\NuGet.exe'
    if (Test-Path -Path $nuGetSourcePath) {
        Write-Host 'Copying NuGet'
        try {
            Copy-Item -Path $nuGetSourcePath -Destination $nuGetPath -Force -EA Stop
        } catch {
            Write-Host $_.Exception.Message
            exit 666
        }
    }
} else {
    Write-Host 'NuGet found'
}

if ([string]::IsNullOrWhiteSpace($env:PSFY_MODULE_NAME) -or [string]::IsNullOrWhiteSpace($env:PSFY_MODULE_GUID)) {
    Write-Host 'Pipeline variables not initialized, running from local moduleinfo.json'
    $jsonPath = Join-Path -Path $PSScriptRoot -ChildPath 'moduleinfo.json'
    if (Test-Path -Path $jsonPath -PathType Leaf) {
        $moduleInfo = (Get-Content -Path $jsonPath | ConvertFrom-Json)
    } else {
        Write-Host 'moduleinfo.json not found!'
        exit 1    
    }
} else {
    $moduleInfo = [PSCustomObject]@{
        'ModuleName' = $env:PSFY_MODULE_NAME
        'ModuleGUID' = $env:PSFY_MODULE_GUID
        'ModuleMajorVersion' = ($env:PSFY_MODULE_VERSION_MAJOR -as [int])
        'ModuleMinorVersion' = ($env:PSFY_MODULE_VERSION_MINOR -as [int])
        'ModulePatch' = ($env:PSFY_MODULE_VERSION_PATCH -as [int])
        'Description' = $env:PSFY_MODULE_DESC
        'RequiredModules' = @()
    }
    if ($null -eq $moduleInfo.ModuleMajorVersion) { $moduleInfo.ModuleMajorVersion = 99 }
    if ($null -eq $moduleInfo.ModuleMinorVersion) { $moduleInfo.ModuleMinorVersion = 99 }
    if ($null -eq $moduleInfo.ModulePatch) { $moduleInfo.ModulePatch = 999 }
}

$reponame = ('repo{0}' -f (Get-Date -Format 'yyyyMMddHHmmss'))
$repopath = Join-Path -Path $PSScriptRoot -ChildPath 'nuget-package'
if (-not (Test-Path -Path $repopath)) {
    Write-Host 'Creating artifact path'
    $null = New-Item -Path $repopath -ItemType Directory -Force
}
$exrepo = Get-PSRepository | Where-Object SourceLocation -eq $repopath
if ($null -eq $exrepo) {
    Write-Host ('Registering {0} as repository {1}' -f $repopath, $reponame)
    try {
        Register-PSRepository -Name $reponame -SourceLocation $repopath -PublishLocation $repopath -PackageManagementProvider NuGet -EA Stop
    } catch {
        Write-Host $_.Exception.Message
        exit 1
    }
} else {
    $reponame = $exrepo.Name
    Write-Host ('Reusing existing repository {0}' -f $reponame)
}

$outputFolder = Join-Path -Path $PSScriptRoot -ChildPath $moduleInfo.ModuleName
if (Test-Path -Path $outputFolder) {
    Write-Host ('Publishing module from {0}' -f $outputFolder)
    try {
        Publish-Module -Path $outputFolder -Repository $reponame -Force -Confirm:$false -EA Stop
    } catch {
        Write-Host $_.Exception.Message
        exit 3
    }
} else {
    Write-Host 'Module output folder not found'
    $rc = 4
}
try {
    Unregister-PSRepository -Name $reponame -EA Stop
} catch {}
exit $rc