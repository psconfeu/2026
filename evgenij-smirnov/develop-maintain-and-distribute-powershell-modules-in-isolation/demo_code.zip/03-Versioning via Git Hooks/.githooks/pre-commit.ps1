[CmdletBinding()]
Param(
    [Parameter(Mandatory=$false, Position=0)]
    [string]$Branch
)
$moduleInfo = $moduleInfo = (Get-Content -Path 'moduleinfo.json' | ConvertFrom-Json)
if ($Branch -match '^major\/') {
    $moduleInfo.ModuleMajorVersion = $moduleInfo.ModuleMajorVersion + 1
    $moduleInfo.ModuleMinorVersion = 0
    $moduleInfo.ModuleBuild = 0
} elseif ($Branch -match '^minor\/') {
    $moduleInfo.ModuleMinorVersion = $moduleInfo.ModuleMinorVersion + 1
    $moduleInfo.ModuleBuild = 0
} else {
    $moduleInfo.ModuleBuild = $moduleInfo.ModuleBuild + 1    
}
$moduleInfo | ConvertTo-Json | Set-Content -Path 'moduleinfo.json' -Force
Invoke-Expression 'git add *'