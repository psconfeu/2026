<#
    Building and distributing modules in isolation

    PSConfEU 2026 | Wiesbaden, Germany

    Evgenij Smirnov @it-pro-berlin.de
    
    Pre-commit scriptlet to increment version numbers
    in moduleinfo.json depending on branch name

    This works fine in a git hook as long as you are the lone contributor
    but creates issues if multile persons work on the same code in parallel
#>
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$false, Position=0)]
    [string]$Branch
)
$moduleInfo = $moduleInfo = (Get-Content -Path 'moduleinfo.json' | ConvertFrom-Json)
if ($Branch -match '^major\/') {
    $moduleInfo.ModuleMajorVersion = $moduleInfo.ModuleMajorVersion + 1
    $moduleInfo.ModuleMinorVersion = 0
    $moduleInfo.ModuleBuild = 0
} elseif ($Branch -match '^minor\/') {
    $moduleInfo.ModuleMinorVersion = $moduleInfo.ModuleMinorVersion + 1
    $moduleInfo.ModuleBuild = 0
} else {
    $moduleInfo.ModuleBuild = $moduleInfo.ModuleBuild + 1    
}
$moduleInfo | ConvertTo-Json | Set-Content -Path 'moduleinfo.json' -Force
Invoke-Expression 'git add *'